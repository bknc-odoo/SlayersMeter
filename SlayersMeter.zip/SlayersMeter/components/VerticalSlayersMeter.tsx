"use client";
import React from "react";

export default function VerticalSlayersMeter({ percent }: { percent: number }) {
  const size = 300;
  const stroke = 20;
  const r = 100;
  const cx = size / 2;
  const cy = size / 2;

  const pctToAngle = (p: number) => (-Math.PI / 2) + (p / 100) * Math.PI;
  const angle = pctToAngle(percent);

  const arcPath = (fromPct: number, toPct: number) => {
    const a1 = pctToAngle(fromPct), a2 = pctToAngle(toPct);
    const x1 = cx + r * Math.cos(a1), y1 = cy + r * Math.sin(a1);
    const x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
    const large = Math.abs(a2 - a1) > Math.PI ? 1 : 0;
    return `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`;
  };

  const bands = [
    { from: 0, to: 50, color: "red" },
    { from: 50, to: 85, color: "orange" },
    { from: 85, to: 100, color: "green" },
  ];

  return (
    <svg viewBox={`0 0 ${size} ${size}`} className="w-full">
      <path d={arcPath(0, 100)} stroke="#ccc" strokeWidth={stroke} fill="none" strokeLinecap="round" />
      {bands.map((b, i) => (
        <path key={i} d={arcPath(b.from, b.to)} stroke={b.color} strokeWidth={stroke} fill="none" strokeLinecap="round" />
      ))}
      <line
        x1={cx}
        y1={cy}
        x2={cx + r * Math.cos(angle)}
        y2={cy + r * Math.sin(angle)}
        stroke="black"
        strokeWidth={4}
      />
      <circle cx={cx} cy={cy} r={5} fill="black" />
      <text x={cx} y={cy - 10} textAnchor="middle" fontSize="24" fontWeight="bold">{percent.toFixed(1)}%</text>
    </svg>
  );
}
