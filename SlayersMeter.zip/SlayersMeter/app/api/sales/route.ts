import { NextResponse } from "next/server";
import { google } from "googleapis";

export const revalidate = 120;

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": process.env.ALLOWED_ORIGIN || "",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, x-api-key",
  Vary: "Origin",
};

export async function OPTIONS() {
  return new NextResponse(null, { status: 204, headers: CORS_HEADERS });
}

export async function GET(req: Request) {
  const apiKey = req.headers.get("x-api-key");
  if (!process.env.X_API_KEY || apiKey !== process.env.X_API_KEY) {
    return new NextResponse(JSON.stringify({ error: "Unauthorized" }), {
      status: 401,
      headers: { "Content-Type": "application/json", ...CORS_HEADERS },
    });
  }

  const url = new URL(req.url);
  const period = (url.searchParams.get("period") || "month").toLowerCase();

  const DEMO = process.env.DEMO === "true";
  if (DEMO) {
    const pct = period === "quarter" ? 30.3 : 37.5;
    return new NextResponse(
      JSON.stringify({ period, percent: pct, label: period === "quarter" ? "This quarter" : "This month" }),
      { headers: { "Content-Type": "application/json", ...CORS_HEADERS } }
    );
  }

  try {
    const auth = new google.auth.JWT(
      process.env.GOOGLE_SHEETS_CLIENT_EMAIL,
      undefined,
      (process.env.GOOGLE_SHEETS_PRIVATE_KEY || "").replace(/\\n/g, "\n"),
      ["https://www.googleapis.com/auth/spreadsheets.readonly"]
    );
    const sheets = google.sheets({ version: "v4", auth });

    const sheetId = process.env.GOOGLE_SHEETS_SHEET_ID!;
    const tab = process.env.GOOGLE_SHEETS_TAB || "Dashboard";
    const range = `${tab}!A2:B3`;

    const res = await sheets.spreadsheets.values.get({ spreadsheetId: sheetId, range });
    const values = res.data.values || [];

    const map: Record<string, number> = {};
    for (const row of values) {
      const [label, percent] = row;
      if (!label) continue;
      map[label.toLowerCase()] = Number(percent || 0);
    }

    const percent = map[period] ?? map["month"] ?? 0;

    return new NextResponse(
      JSON.stringify({ period, percent, label: period === "quarter" ? "This quarter" : "This month" }),
      { headers: { "Content-Type": "application/json", ...CORS_HEADERS } }
    );
  } catch (e: any) {
    return new NextResponse(JSON.stringify({ error: e?.message || "Sheets error" }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...CORS_HEADERS },
    });
  }
}
