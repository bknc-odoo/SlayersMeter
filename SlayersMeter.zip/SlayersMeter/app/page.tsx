import VerticalSlayersMeter from "@/components/VerticalSlayersMeter";

async function getData(period: "month" | "quarter") {
  const res = await fetch(`${process.env.NEXT_PUBLIC_BASE_URL || ""}/api/sales?period=${period}`, {
    headers: { "x-api-key": process.env.X_API_KEY || "" },
    cache: "no-store",
  });
  if (!res.ok) return { percent: 0 };
  return res.json();
}

export default async function Page() {
  const monthData = await getData("month");
  const quarterData = await getData("quarter");

  return (
    <main style={{ padding: "2rem" }}>
      <h1>SlayersMeter</h1>
      <div style={{ display: "flex", gap: "2rem" }}>
        <div>
          <h2>This Month</h2>
          <VerticalSlayersMeter percent={monthData.percent} />
        </div>
        <div>
          <h2>This Quarter</h2>
          <VerticalSlayersMeter percent={quarterData.percent} />
        </div>
      </div>
    </main>
  );
}
